DataInter v1.0 for VB

Data Interchange ActiveX


Data interchange between applications has always been a hard task to implement. Now you can use DataInter to provide powerful data interchange between different programs (or even different instances of the same program).


Usage of the library
��������������������
All the functions are encapsulated in the file DataInter.ocx and it must be distributed with your application.



Methods:
��������
Connect(ByVal ChannelNum As Long) As Boolean

This method connects to a data interchange session. ChannelNum is the channel you want to connect to. All applications connected to the same channel will be able to interchange data. If the channel specified does not exist, it is created. Returns True if succeeded.


Finish()

This method closes the data interchange session. If calling application is the last in the channel, it is destroyed.


SendData(Data As String, Optional ByVal BlockToSelf As Boolean)

This method sends Data to other applications. if BlockToSelf is True, then the application sending the data won't receive the message; otherwise it will receive the message as if it was another application.



Events:
�������

DataReceived(Data As String)

This event is raised when a new data message has been received.


Event ReceptorConnected()

This event is raised whenever an application connects to the current channel.


Event ReceptorDisconnected()

This event is raised whenever an application disconnects from the current channel.



Properties:
�����������

Interval As Long

This property controls the amount of time (in milliseconds) to wait to check new data messages. Default value is 200.


Receptors As Long (Read-only)

This is the number of applications connected to the current channel.






This control is provided "as is" without any kind of warranty. I am not responsible of the changes that this control could eventually make to your system.

Copyright � 2003 Paul Guerra. All rights reserved.